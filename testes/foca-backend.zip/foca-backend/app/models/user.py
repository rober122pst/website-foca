# User model
from pydantic import BaseModel, EmailStr
from typing import Optional

class User(BaseModel):
    id: Optional[str]
    nome: str
    email: EmailStr
    senha_hash: str
    xp: int = 0
