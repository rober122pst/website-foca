# User routes
from fastapi import APIRouter

router = APIRouter()

@router.get('/')
def get_users():
    return {"message": "Listagem de usuários"}
