# Auth placeholder (token functions aqui futuramente)
