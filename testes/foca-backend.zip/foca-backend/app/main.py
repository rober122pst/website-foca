# FastAPI app entry point
from fastapi import FastAPI
from app.routes import user, task, session

app = FastAPI()

app.include_router(user.router, prefix='/users')
app.include_router(task.router, prefix='/tasks')
app.include_router(session.router, prefix='/sessions')

@app.get('/')
def root():
    return {'message': 'Foca API online!'}
